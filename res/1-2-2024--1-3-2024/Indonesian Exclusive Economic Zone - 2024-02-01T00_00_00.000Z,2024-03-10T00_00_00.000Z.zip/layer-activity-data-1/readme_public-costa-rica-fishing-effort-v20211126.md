
## Costa Rica VMS dataset
Downloaded date: Mar 13 2024 05:50 UTC
API Dataset versions: public-costa-rica-fishing-effort:v20211126

### Description
Description pending

Filters:  timestamp >= '2024-02-01T00:00:00.000Z' and timestamp <= '2024-03-10T00:00:00.000Z'
Group by: flagAndGearType
Temporal resolution: daily (data is grouped by flagAndGearType and summarized by day)
Spatial aggregation: true


### Columns

* Time Range: The data format depends on the temporal resolution, for monthly (YYYY-MM), for daily (YYYY-MM-DD), for yearly (YYYY) and for entire the date-range query param value.
* flagAndGearType: flagAndGearType.
* Vessel IDs: Number of different vessel ids.

flagAndGearType.
* Apparent Fishing Hours: Hours that the vessel associated with this vessel_id was fishing in the grid cell over the selected time range


## License
Unless otherwise stated, Global Fishing Watch data is licensed under a Creative Commons Attribution-ShareAlike 4.0 International license and code under an Apache 2.0 license.

For additional information about:
these results, see the associated journal article: D.A. Kroodsma, J. Mayorga, T. Hochberg, N.A. Miller, K. Boerder, F. Ferretti, A. Wilson, B. Bergman, T.D. White, B.A. Block, P. Woods, B. Sullivan, C. Costello, and B. Worm. "Tracking the global footprint of fisheries." Science 361.6378 (2018). http://science.sciencemag.org/content/359/6378/904 
Data caveats and details: https://globalfishingwatch.org/dataset-and-code-fishing-effort/ 
	
## Suggested Citation

Global Fishing Watch. 2022, updated daily. Vessel apparent fishing effort v20211126, [Feb 01 2024 00:00 UTC Mar 10 2024 00:00 UTC]. Data set accessed 2024-03-13 at https://globalfishingwatch.org/map

